import Pengaduan from '../components/pengaduan/Pengaduan'

function ComplaintPage() {
  return (
    <>
      <Pengaduan />
    </>
  )
}

export default ComplaintPage
