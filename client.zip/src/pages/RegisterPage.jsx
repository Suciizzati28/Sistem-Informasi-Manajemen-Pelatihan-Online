import Pendaftaran from '../components/pendaftaran/Pendaftaran'

const RegisterPage = () => {
  return <Pendaftaran />
}

export default RegisterPage
