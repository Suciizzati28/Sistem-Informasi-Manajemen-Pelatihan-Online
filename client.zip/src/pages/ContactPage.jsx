import Kontak from '../components/kontak/Kontak';

function ContactPage() {
  return (
    <div className="App">
        <Kontak />
      <div className='container mt-5'>
      </div>
      <div className='container mt-5'>
      </div>
    </div>
  );
}

export default ContactPage;
