export { default as Dashboard } from './Dashboard'
export { default as TrainerDashboard } from './TrainerDashboard'
export { default as TrainersDashboard } from './TrainersDashboard'
export { default as TrainersFormPage } from './TrainersFormPage'

export { default as ComplaintsDashboard } from './ComplaintsDashboard'

export { default as TrainingsFormPage } from './TrainingsFormPage'
export { default as TrainingsDashboard } from './TrainingsDashboard'
export { default as TrainingDashboard } from './TrainingDashboard'

export { default as AdminsDashboard } from './AdminsDashboard'

export { default as ParticipantsDashboard } from './ParticipantsDashboard'
export { default as YellowCardsDashboard } from './YellowCardsDashboard'