function TrainingDashboard() {
  return (
    <div>
      <div>Training Dashboard</div>
    </div>
  )
}

export default TrainingDashboard
