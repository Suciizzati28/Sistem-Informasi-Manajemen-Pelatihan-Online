import Hero from '../components/home/Hero'
import Konten from '../components/home/Konten'
import Konten1 from '../components/home/Konten1'


function IndexPage() {
    return(
        <div>
            <Hero/>
            <Konten/>
            {/* <Konten1/> */}
        </div>
    )
}

export default IndexPage;